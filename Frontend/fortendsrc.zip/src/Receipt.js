import React from 'react'

function Receipt() {
  return (
    <div>
        fjhvjhgj,hg
    </div>
  )
}

export default Receipt;
